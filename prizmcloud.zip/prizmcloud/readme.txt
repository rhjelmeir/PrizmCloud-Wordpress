##PrizmCloud Emebbed Document Viewer for Wordpress

Wordpress plugin for PrizmCloud Embedded Document Viewer. Embed our document viewer in your site. Your visitors view your documents in any of 300+ file types. Just like that.

You will need a PrizmCloud account to use PrizmCloud Document Viewer. [PrizmCloud Sign Up](http://prizmcloud.accusoft.com/register.html "PrizmCloud") 

View a [demo](http://prizmcloud.accusoft.com/demo.html)

##Manual Installation Instructions

1. Download zip file
2. Log into Wordpress Admin
3. Click on Plugins menu, click Add New
4. Click Upload
5. Choose the downloaded zip and click Install Now

